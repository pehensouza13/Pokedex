import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:pokedex/firebase_options.dart';
import 'package:pokedex/firebase_options.dart';
import 'package:pokedex/pages/login_pages.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
        apiKey: "AIzaSyAsfyWx7kZAT1sQlsTRiZrFwX4BxZjYo-8",
        authDomain: "pokedex-app-pe.firebaseapp.com",
        projectId: "pokedex-app-pe",
        storageBucket: "pokedex-app-pe.firebasestorage.app",
        messagingSenderId: "652317127103",
        appId: "1:652317127103:web:078c0f9127bff37c01f10a"),
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(),
    );
  }
}
